package test;

import appointment.Appointment;
import appointment.AppointmentService;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in future
        Appointment appointment = new Appointment("12345", futureDate, "Valid Description");

        service.addAppointment(appointment);
        assertThrows(IllegalArgumentException.class, () -> 
            service.addAppointment(appointment) // Attempt to add duplicate
        );
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        Appointment appointment = new Appointment("12345", futureDate, "Valid Description");

        service.addAppointment(appointment);
        assertTrue(service.deleteAppointment("12345"));
        assertFalse(service.deleteAppointment("12345")); // Deleting again should return false
    }

    @Test
    void testDeleteNonExistentAppointment() {
        AppointmentService service = new AppointmentService();
        assertFalse(service.deleteAppointment("99999")); // Should return false for non-existent ID
    }
}
