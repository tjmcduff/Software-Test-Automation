package test;

import appointment.Appointment;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    @Test
    void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000); // 1 day in future
        Appointment appointment = new Appointment("12345", futureDate, "Valid Description");

        assertEquals("12345", appointment.getAppointmentID());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Valid Description", appointment.getDescription());
    }

    @Test
    void testAppointmentIDTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345678901", futureDate, "Valid Description")
        );
    }

    @Test
    void testAppointmentIDNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment(null, futureDate, "Valid Description")
        );
    }

    @Test
    void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 86400000); // 1 day in past
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345", pastDate, "Valid Description")
        );
    }

    @Test
    void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345", null, "Valid Description")
        );
    }

    @Test
    void testDescriptionTooLong() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345", futureDate, "This description is way too long and exceeds the fifty character limit")
        );
    }

    @Test
    void testDescriptionNull() {
        Date futureDate = new Date(System.currentTimeMillis() + 86400000);
        assertThrows(IllegalArgumentException.class, () -> 
            new Appointment("12345", futureDate, null)
        );
    }
}
