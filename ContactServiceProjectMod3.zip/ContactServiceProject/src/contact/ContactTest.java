package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreationValid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        assertEquals("12345", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Elm Street", contact.getAddress());
    }

    @Test
    void testContactCreationInvalidID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Contact ID must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Doe", "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Contact ID must not be null"));
    }

    @Test
    void testContactCreationInvalidFirstName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Doe", "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("First name must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Johnathan123", "Doe", "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("First name must not be null"));
    }

    @Test
    void testContactCreationInvalidLastName() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", null, "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Last name must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doeeeeeeeeee", "1234567890", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Last name must not be null"));
    }

    @Test
    void testContactCreationInvalidPhone() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", null, "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Phone must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "12345", "123 Elm Street");
        });
        assertTrue(exception.getMessage().contains("Phone must not be null"));
    }

    @Test
    void testContactCreationInvalidAddress() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "1234567890", null);
        });
        assertTrue(exception.getMessage().contains("Address must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street that has way too many characters");
        });
        assertTrue(exception.getMessage().contains("Address must not be null"));
    }

    @Test
    void testSettersValid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());

        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());

        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());

        contact.setAddress("456 Oak Street");
        assertEquals("456 Oak Street", contact.getAddress());
    }

    @Test
    void testSettersInvalid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
        assertTrue(exception.getMessage().contains("First name must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
        assertTrue(exception.getMessage().contains("Last name must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("12345");
        });
        assertTrue(exception.getMessage().contains("Phone must not be null"));

        exception = assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("123 Elm Street that has way too many characters");
        });
        assertTrue(exception.getMessage().contains("Address must not be null"));
    }
}
