package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    @Test
    void testAddContactValid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    void testAddContactDuplicateID() {
        Contact contact1 = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        Contact contact2 = new Contact("12345", "Jane", "Smith", "0987654321", "456 Oak Street");
        contactService.addContact(contact1);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.addContact(contact2);
        });
        assertTrue(exception.getMessage().contains("Contact with this ID already exists"));
    }

    @Test
    void testDeleteContactValid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    @Test
    void testDeleteContactNonexistentID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.deleteContact("12345");
        });
        assertTrue(exception.getMessage().contains("Contact with this ID does not exist"));
    }

    @Test
    void testUpdateContactValid() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);

        contactService.updateContact("12345", "Jane", "Smith", "0987654321", "456 Oak Street");

        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Oak Street", updatedContact.getAddress());
    }

    @Test
    void testUpdateContactNonexistentID() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            contactService.updateContact("12345", "Jane", "Smith", "0987654321", "456 Oak Street");
        });
        assertTrue(exception.getMessage().contains("Contact with this ID does not exist"));
    }

    @Test
    void testUpdateContactPartialFields() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);

        contactService.updateContact("12345", null, "Smith", null, "456 Oak Street");

        Contact updatedContact = contactService.getContact("12345");
        assertEquals("John", updatedContact.getFirstName()); // Should remain unchanged
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("1234567890", updatedContact.getPhone()); // Should remain unchanged
        assertEquals("456 Oak Street", updatedContact.getAddress());
    }
}
