package contact;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    // In-memory data structure to store contacts
    private final Map<String, Contact> contactMap;

    // Constructor
    public ContactService() {
        contactMap = new HashMap<>();
    }

    // Add a new contact
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }
        if (contactMap.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact with this ID already exists.");
        }
        contactMap.put(contact.getContactID(), contact);
    }

    // Delete a contact by ID
    public void deleteContact(String contactID) {
        if (!contactMap.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact with this ID does not exist.");
        }
        contactMap.remove(contactID);
    }

    // Update a contact's fields
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (!contactMap.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact with this ID does not exist.");
        }

        // Fetch the contact and update fields
        Contact contact = contactMap.get(contactID);

        if (firstName != null && !firstName.isEmpty()) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && !lastName.isEmpty()) {
            contact.setLastName(lastName);
        }
        if (phone != null && !phone.isEmpty()) {
            contact.setPhone(phone);
        }
        if (address != null && !address.isEmpty()) {
            contact.setAddress(address);
        }
    }

    // Retrieve a contact by ID (Optional for debugging/testing)
    public Contact getContact(String contactID) {
        return contactMap.get(contactID);
    }
}
